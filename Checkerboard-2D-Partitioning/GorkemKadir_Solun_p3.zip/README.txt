Görkem Kadir Solun 22003214 CS426 Project 3

I prepared my inputs and run the project in the ORFOZ with them but the inputs are not provided with the submission zip as they are not asked.
Beware that the input file names are currently present in the slurm.sh file, they can be removed.
Output file names can be given when running the programs.
I have also provided row parallel implementation under "row_parallel.c"